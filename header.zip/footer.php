	<div class="container">
	
			</div>
			<div class="social-icons">
				<a class="facebook" href="#">
					<span class="fa fa-facebook"></span>
				</a>
				<a class="twitter" href="#">
					<span class="fa fa-twitter"></span>
				</a>
				<a class="pinterest" href="#">
					<span class="fa fa-pinterest-p"></span>
				</a>
				<a class="linkedin" href="#">
					<span class="fa fa-linkedin"></span>
				</a>
			</div>
		</div>
	</div>
	<div class="copy">
		<div class="container">
			<h2 class="footer-logo">
				<a href="index.html">
				<div class="row" >
					<span>G</span>ST</a>
					</div>
				<div class="row"style="font-size:15px">
					<span style="color:white">Genuine Solution Of Taxes</span>
			    </div>
			</h2>
			<p>© 2020 GST . All Rights Reserved.</p>
			<div class="clearfix"></div>
		</div>
	</div>
	<!--/footer -->