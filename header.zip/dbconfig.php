<?php
//$con=mysqli_connect("mysql1005.mochahost.com","saueriex_gst","123456","saueriex_gst_db");
$con=mysqli_connect("localhost","root","","gst_db") or die(mysqli_error());
error_reporting(1);
?>