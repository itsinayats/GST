<?php
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
?>
<style>
.img-center {margin:0 auto;margin-bottom:10px;}	
.tr {
	background:transparent !important;
	color:white !important;
	border:none;
	padding:5px;
	
}
label,input{color:white}
.white{color:white}
</style>
<div class="container-fluid" >
    <div class="row">
        <div class="col-sm-3">
		
	
            <!--left col-->
			<img width="200px" height="200px" title="profile image" class="img-responsive img-center" src="uploads/<?php echo $_SESSION['id']."/avatar.jpeg" ?>">

<div class="text-center white"> <h2>INAYAT HUSSAIN</h2><hr></div>
  

          

           
          
        </div>
        <!--/col-3-->
        <div class="col-sm-9">
		
		<div class="row" style="float:right;color:white;margin-right:10px">
		<a href="dashboard.php?tab=ef" class="white">Edit Details:<i class="glyphicon glyphicon-edit white"></i></a>
		</div>

           

      <div class="row">
                    <form class="form"  action="#" method="post" id="registrationForm">
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="first_name">
                                    <h4>Last Name</h4></label>
                                <input disabled type="text" class="tr " name="first_name" id="first_name" placeholder="----">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="last_name">
                                    <h4>Last name</h4></label>
                                <input disabled type="text" class="tr " name="last_name" id="last_name" placeholder="----">
                            </div>
                        </div>

                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="phone">
                                    <h4>Phone</h4></label>
                                <input disabled type="text" class="tr " name="phone" id="phone" placeholder="----" >
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="mobile">
                                    <h4>Mobile</h4></label>
                                <input disabled type="text" class="tr " name="mobile" id="mobile" placeholder="----">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="email">
                                    <h4>Email</h4></label>
                                <input disabled type="email" class="tr " name="email" id="email" placeholder="----" >
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="email">
                                    <h4>Location</h4></label>
                                <input disabled type="email" class="tr " id="location" placeholder="----" >
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password">
                                    <h4>Password</h4></label>
                                <input disabled  type="password" class="tr " name="password" id="password" placeholder="----" >
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password2">
                                    <h4>Verify</h4></label>
                                <input disabled  type="password" class="tr " name="password2" id="password2" placeholder="----">
                            </div>
                        </div>
						  <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password">
                                    <h4>Password</h4></label>
                                <input disabled type="password" class="tr " name="password" id="password" placeholder="----" >
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password2">
                                    <h4>Verify</h4></label>
                                <input disabled type="password" class="tr " name="password2" id="password2" placeholder="----">
                            </div>
                        </div>
						  <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password">
                                    <h4>Password</h4></label>
                                <input disabled type="password" class="tr " name="password" id="password" placeholder="----" >
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password2">
                                    <h4>Verify</h4></label>
                                <input disabled type="password" class="tr " name="password2" id="password2" placeholder="----">
                            </div>
                        </div>
						  <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password">
                                    <h4>Password</h4></label>
                                <input disabled type="password" class="tr " name="password" id="password" placeholder="----" >
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password2">
                                    <h4>Verify</h4></label>
                                <input disabled type="password" class="tr " name="password2" id="password2" placeholder="----">
                            </div>
                        </div>
						  <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password">
                                    <h4>Password</h4></label>
                                <input disabled type="password" class="tr " name="password" id="password" placeholder="----" >
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="password2">
                                    <h4>Verify</h4></label>
                                <input disabled type="password" class="tr " name="password2" id="password2" placeholder="----">
                            </div>
                        </div>
                      
                    </form>
                </div>
				</div>

            </div>
            <!--/tab-pane-->
        </div>
        <!--/tab-content-->

    </div>
    <!--/col-9-->
</div>
<!--/row-->