<?php
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
?>
<?php

if(isset($_POST['btn-upload-avatar'])){
mkdir ("uploads/".$_SESSION['id'], 0755);
$target_dir = "uploads/".$_SESSION['id']."/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$target_file =  $target_dir . "avatar" . "."."jpeg";
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
/*if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
*/
// Check file size
if ($_FILES["fileToUpload"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
) {
    echo "Sorry, only JPG, JPEG, PNG & PDF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded";
		$location="/gst.ringel.in"."/".$target_file;
		$name_of_file=basename( $_FILES["fileToUpload"]["name"]);
		$id=$_SESSION['id'];
	$description=	$_POST['description'];
		//file upload to dba_close
$sql="insert into files(name,description,path,userid) values ('$name_of_file','$description','$location','$id')";
mysqli_query($con,$sql);
		
		
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
}
?>



<style>
.img-center {margin:0 auto;margin-bottom:10px;}	

}
.white{color:white !important}
</style>
<div class="container-fluid" style="margin-top:10px;" >
    <div class="row">
        <div class="col-sm-3">
		
	
            <!--left col-->
<img width="200px" height="200px" title="profile image" class="img-responsive img-center" src="uploads/<?php echo $_SESSION['id']."/avatar.jpeg" ?>">
<form method="post" enctype="multipart/form-data">
<div class="">
<input type="file" class="btn-info btn" name="fileToUpload" >
<input class="btn btn-warning btn-sm" type="submit" value="upload" name="btn-upload-avatar">
</div>

</form>
<br>

  

          

           
          
        </div>
        <!--/col-3-->
        <div class="col-sm-9">

           

      
                    <form class="form"  action="#" method="post" id="registrationForm">
                        <div class="form-group">

                            <div class="col-md-6">
                                <label for="first_name">
                                    <h4>First name</h4></label>
                                <input type="text" class="form-control" name="first_name" id="first_name" placeholder="first name" title="enter your first name if any.">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-md-6">
                                <label for="last_name">
                                    <h4>Last name</h4></label>
                                <input type="text" class="form-control" name="last_name" id="last_name" placeholder="last name" title="enter your last name if any.">
                            </div>
                        </div>

                        <div class="form-group">

                            <div class="col-md-6">
                                <label for="phone">
                                    <h4>Phone</h4></label>
                                <input type="text" class="form-control" name="phone" id="phone" placeholder="enter phone" title="enter your phone number if any.">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6">
                                <label for="mobile">
                                    <h4>Mobile</h4></label>
                                <input type="text" class="form-control" name="mobile" id="mobile" placeholder="enter mobile number" title="enter your mobile number if any.">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-md-6">
                                <label for="email">
                                    <h4>Email</h4></label>
                                <input type="email" class="form-control" name="email" id="email" placeholder="you@email.com" title="enter your email.">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-md-6">
                                <label for="email">
                                    <h4>Location</h4></label>
                                <input type="email" class="form-control" id="location" placeholder="somewhere" title="enter a location">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-md-6">
                                <label for="password">
                                    <h4>Password</h4></label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="password" title="enter your password.">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-md-6">
                                <label for="password2">
                                    <h4>Verify</h4></label>
                                <input type="password" class="form-control" name="password2" id="password2" placeholder="password2" title="enter your password2.">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-12">
                                <br>
                                <button class="btn btn-md btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                <button class="btn btn-md" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
								  <button class="btn btn-md btn-info" type="button" onclick="window.history.back();"><i class="glyphicon glyphicon-arrow-left"></i> Back</button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
            <!--/tab-pane-->
        </div>
        <!--/tab-content-->
</div>
</body>
