<style>
.border-cp {
    border: solid 1px;
    padding: 20px;
}
</style>
	<!-- contact -->
	<div class="contact-innpage" style="padding-top:15px">
		<div class="container" style="max-width:500px">

			
				
				<div class="contact-right-grid-login border-cp">
							<h3>Change Password</h3><br>
					<form method="post">
						    <input type="password" name="pass" placeholder="Password" required="">
							<input type="password" name="cnf_pass" placeholder="Confirm Password" required="">
						<input type="submit" class="btn btn-sm btn-warning" style="background:#546513;" value="change" name="btn-change-pass">
							</form>
				</div>
				<div class="clearfix"> </div>
		
		</div>
	</div>
	